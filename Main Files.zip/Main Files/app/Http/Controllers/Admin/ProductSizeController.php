<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductSizeRequest;
use App\Models\Admin\ProductSize;
use App\Models\Admin\ProductTag;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class ProductSizeController extends Controller
{

}
