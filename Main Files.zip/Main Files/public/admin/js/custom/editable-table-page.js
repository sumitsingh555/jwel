// Editable table
var example1 = new BSTable("table1");
example1.init();