<?php
return[
    'category'=>'Category',
    'search_here'=>'Search Here',
    'wishlist'=>'Wishlist',
    'compare'=>'Compare',
    'cart'=>'Your Cart',
    'home'=>'Home',
    'shop'=>'Shop',
    'pages'=>'Pages',
    'about_us'=>'About Us',
    'blog'=>'Blog',
    'contact'=>'Contact'
];
