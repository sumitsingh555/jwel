<?php
return[
    'category'=>'Catégorie',
    'search_here'=>'Cherche ici',
    'wishlist'=>'Liste de souhaits',
    'compare'=>'Comparer',
    'cart'=>'Votre panier',
    'home'=>'Accueil',
    'shop'=>'Boutique',
    'pages'=>'Pages',
    'about_us'=>'À propos de nous',
    'blog'=>'Blog',
    'contact'=>'prendre contact'
];
