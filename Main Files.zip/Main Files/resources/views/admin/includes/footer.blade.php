<!-- Footer section start -->
<footer class="footer__area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="footer__copyright">
                    <div class="footer__copyright__left">
                        <h2>{{date('Y')}} &copy; {{$allsettings['app_title']}}</h2>
                    </div>
                    <div class="footer__copyright__right">
                        <h2>{{ $allsettings['footer_title']}}</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer section end -->
