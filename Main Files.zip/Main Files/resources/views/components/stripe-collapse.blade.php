
<label class="mt-3" for="card-element">
    {{__('Card details:')}}
</label>

<div id="cardElement"></div>

<small class="form-text text-muted" id="cardErrors" role="alert"></small>

<input type="hidden" name="payment_method" id="paymentMethod">

